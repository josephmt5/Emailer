<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
	<style>
	html, body
		{
			background-color:darkred;
		}
	</style>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<h1>You do not have authorization to access this page if you believe this is an error please contact your system administrator</h1>
	<a margin-left="40%" href="http://control.apptcenter.com">Return Home</a>
<body>
</body>
</html>