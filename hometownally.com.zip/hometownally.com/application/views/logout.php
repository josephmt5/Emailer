<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>error</title>
</head>

<body onload="signOut">
	you should never see this page
	
	
		
		
		<?
		$this->session->sess_destroy();
	    redirect("Welcome/index");
		
		
		
		
		?>
		
		
		
		
		
		
	
		</script>
</body>
</html>